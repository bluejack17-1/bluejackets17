<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use LINE\LINEBot\Constant\HTTPHeader;
use LINE\LINEBot\Event\FollowEvent;
use LINE\LINEBot\Event\JoinEvent;
use LINE\LINEBot\Event\LeaveEvent;
use LINE\LINEBot\Event\MessageEvent;
use LINE\LINEBot\Event\UnfollowEvent;
use LINE\LINEBot\Exception\InvalidEventRequestException;
use LINE\LINEBot\Exception\InvalidSignatureException;

use App\Http\Controllers\BotEventHandlers\MessageEventHandler;
use App\Http\Controllers\BotEventHandlers\FollowEventHandler;
use App\Http\Controllers\BotEventHandlers\UnfollowEventHandler;
use App\Http\Controllers\BotEventHandlers\JoinEventHandler;
use App\Http\Controllers\BotEventHandlers\LeaveEventHandler;

class LineBotController {
	public static function routes($app) {
		$app->post('/webhook', 'LineBotController@hook');
	}
	public function hook(Request $request) {
		$bot = app(\App\LINEBot::class)->bot();
		$signature = $request->headers->get(HTTPHeader::LINE_SIGNATURE);

		if (empty($signature)) {
			return response('Bad request', 400);
		}
		
		try {
			$events = $bot->parseEventRequest($request->getContent(), $signature);
		} catch (InvalidSignatureException $e) {
			return response('Invalid signature', 400);
		} catch (InvalidEventRequestException $e) {
			return response('Invalid event request', 401);
		}
		
		foreach ($events as $event) {
			if ($event instanceof MessageEvent) {
				MessageEventHandler::handle($bot, $event);
			}
			else if ($event instanceof FollowEvent) {
				FollowEventHandler::handle($bot, $event);
			}
			else if ($event instanceof UnfollowEvent) {
				UnfollowEventHandler::handle($bot, $event);
			}
			else if ($event instanceof JoinEvent) {
				JoinEventHandler::handle($bot, $event);
			}
			else if ($event instanceof LeaveEvent) {
				LeaveEventHandler::handle($bot, $event);
			}
		}

		return response('OK', 200);
	}

	public function associateForm(Request $request, $uid) {
		if ($request->user()) {
			return redirect()->route('bot.associate', [
				'user_id' => $request->input('user_id'),
			]);
		}
		return view('bots.associate', [
			'user_id' => $uid
		]);
	}
	public function registerForm(Request $request, $uid) {
		return view('bots.register', [
			'user_id' => $uid
		]);
	}
	public function validate(Request $request, $uid, $phone) {
		$user = User::where('phone', $phone)->first();
		if ($user) {
			$line_user = $user->line_user;
			if ($line_user) {
				if ($line_user->user_id === $uid) {
					return view('bots.validate', [
						'success' => 'Welcome to Ancilla Domini.'
					]);
				}
			}
		}
		return view('bots.validate', [
			'error' => 'Unknown error.'
		]);
	}

	public function associate(Request $request) {
		if ($request->user()) {
			if ($request->user()->line_user) {
				return redirect()->route('bot.associateForm', [
					'uid' => $request->input('user_id'),
					'error' => 'Already associated.'
				]);
			}
			$line_user = LineUser::where('user_id', $request->input('user_id'))->first();
			if (!$line_user) {
				return redirect()->route('bot.associateForm', [
					'uid' => $request->input('user_id'),
					'error' => 'Invalid data. Are you friends with bot?'
				]);
			}
			$request->user()->line_user()->associate($line_user);
			$request->user()->save();
			return redirect()->route('bot.validate', [
				'uid' => $request->input('user_id'),
				'phone' => $request->user()->phone
			]);
		}
		return redirect()->route('bot.associateForm', [
			'uid' => $request->input('user_id'),
			'error' => 'Failed to login.'
		]);
	}
	public function register(Request $request) {
		if (User::where('phone', $request->input('phone'))->first()) {
			return redirect()->route('bot.associateForm', [
				'uid' => $request->input('user_id'),
				'error' => 'Already registered.'
			]);
		}
		$validator = \Illuminate\Support\Facades\Validator::make($request->all(), [
			'user_id' => 'required',
			'name' => 'required',
			'password' => 'required|confirmed',
			'address' => 'required',
			'birthplace' => 'required',
			'birthdate' => 'required',
			'phone' => 'required|unique:users,phone',
			'major' => 'required',
			'binusian' => 'required|digits:4'
		]);
		if ($validator->fails()) {
			return redirect()->route('bot.registerForm', [
				'uid' => $request->input('user_id'),
				'error' => 'Form validation failed.'
			]);
		}

		$uid = $request->input('user_id');
		$line_user = LineUser::where('user_id', $request->input('user_id'))->first();
		
		if (!$line_user) {
			return redirect()->route('bot.registerForm', [
				'uid' => $request->input('user_id'),
				'error' => 'Invalid data. Are you friends with bot?'
			]);
		}
		$user = new User();
		$user->password = hash('sha512', $request->input('password'));
		$user->name = $request->input('name');
		$user->address = $request->input('address');
		$user->birthplace = $request->input('birthplace');
		$user->birthdate = $request->input('birthdate');
		$user->phone = $request->input('phone');
		$user->major = $request->input('major');
		$user->binusian = $request->input('binusian');
		$user->voice = $request->input('voice');
		$user->role()->associate(Role::where('name', 'member')->first());
		$user->line_user()->associate($line_user);
		$user->save();
		
		return redirect()->route('bot.validate', [
			'uid' => $request->input('user_id'),
			'phone' => $request->input('phone')
		]);
	}
}