<?php

namespace App\Http\Controllers\BotEventHandlers;

class UnfollowEventHandler {
	public static function handle($bot, $event) {
		if ($event->getUserId()) {
		}
	}
}