<?php

namespace App\Http\Controllers\BotEventHandlers;

class FollowEventHandler {
	public static function handle($bot, $event) {
		if ($event->getUserId()) {
		}
	}
}